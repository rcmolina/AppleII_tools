/***********************************************************************/
/*                                                                     */
/*  a65816_Data.h : Header pour la g�n�ration des Data.                */
/*                                                                     */
/***********************************************************************/
/*  Auteur : Olivier ZARDINI  *  Brutal Deluxe Software  *  Janv 2011  */
/***********************************************************************/

int BuildAllDataLineSize(struct omf_segment *);
int BuildAllDataLine(struct omf_segment *);

/***********************************************************************/
